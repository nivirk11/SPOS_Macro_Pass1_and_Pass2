
public class MNT {
	
	String name;
	int pp,kp,kpdtp,mdtp;
	
	MNT()
	{
		name = null;
		pp=-1;
		kp=-1;
		kpdtp=-1;
		mdtp=-1;
		
	}


}
