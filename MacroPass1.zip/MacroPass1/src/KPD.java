
public class KPD 
{
	String name="",value="";
}
