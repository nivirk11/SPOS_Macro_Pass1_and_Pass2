import java.util.ArrayList;

public class Table {
	ArrayList<String> name  = new ArrayList<>();
	int mnt=-1;
}
